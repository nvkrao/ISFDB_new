create sequence LoginSeqNo 
/
